package com.example.semana4_

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        llamarbt1()
    }

    fun llamarbt1(){
        val bt2 = findViewById<Button>(R.id.bt2)

        bt2.setOnClickListener(){
            val next: Intent = Intent(this, MainActivity2::class.java)
            startActivity(next)
        }
    }
}